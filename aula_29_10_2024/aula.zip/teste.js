function constante(){
	const valor = 10;
	document.write("O valor constante é " + valor);	
}
